package com.example.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.dao.CanvasChartDao;
import com.example.model.MutualFunds;
import com.example.model.Population;
import com.example.model.Product;
import com.example.model.WrapperList;


@Controller
public class MyController
{
	@Autowired
	private CanvasChartDao canvasChartService;
	
	//@Autowired
	ServletContext context;
	
	@RequestMapping("/")
	public String home()
	{
		System.out.println("home called..........");
		return "login";
	}
	
	@RequestMapping(value= {"/loginProcess"},method=RequestMethod.POST)
	public ModelAndView checkLogin(HttpServletRequest request)
	{
		//HttpSession session = request.getSession();
		context = request.getServletContext();
		ModelAndView mav = null;
		String userName = request.getParameter("username");
		String password = request.getParameter("password");
		if(userName.equals("admin") && password.equals("admin"))
		{
			context.setAttribute("userName", userName);
			List<Product>totalProdList = new ArrayList<>();
			Product p1 = new Product();
			p1.setProd_Name("Computer");
			p1.setRemaning_Quantity("3");
			Product p2 = new Product();
			
			p2.setProd_Name("Printer");
			p2.setRemaning_Quantity("2");
			totalProdList.add(p1);
			totalProdList.add(p2);
		    List<List<Map<Object, Object>>> canvasjsDataList = canvasChartService.getCanvasjsChartData(totalProdList);
		    List<Population>populationList = new ArrayList<>();
		    Population obj1 = new Population();
		    obj1.setCountry("India");
		    obj1.setPopulation("50000");
		    Population obj2 = new Population();
		    obj2.setCountry("China");
		    obj2.setPopulation("70000");
		    Population obj3 = new Population();
		    obj3.setCountry("England");
		    obj3.setPopulation("10000");
		    Population obj4 = new Population();
		    obj4.setCountry("USA");
		    obj4.setPopulation("15000");
		    Population obj5 = new Population();
		    obj5.setCountry("Canada");
		    obj5.setPopulation("5000");
		    populationList.add(obj1);
		    populationList.add(obj2);
		    populationList.add(obj3);
		    populationList.add(obj4);
		    populationList.add(obj5);
		    List<List<Map<Object, Object>>> canvasjsDataList2 = canvasChartService.getCanvasjsDataPopulatonList(populationList);
		    	    
		    List<List<Map<Object, Object>>> canvasjsDataList3 = canvasChartService.getCanvasjsDataNumberingList();
		    List<List<Map<Object, Object>>> canvasjsDataList4 = canvasChartService.getCanvasjsDataNumberingList2();
		    List<MutualFunds>mutualList = new ArrayList<>();
		    MutualFunds mObj = new MutualFunds();
		    mObj.setHdfcfund(454.4);
		    mObj.setIcicifund(233.0);
		    mObj.setLicfund(567.67);
		    mObj.setSbifund(333.90);
		    mutualList.add(mObj);
		    
		    WrapperList wrapperList = new WrapperList();
		    wrapperList.setList(mutualList);
		    
			mav = new ModelAndView("HomePage");
			mav.addObject("dataPointsList",canvasjsDataList);
			mav.addObject("dataPointsList2",canvasjsDataList2);
			mav.addObject("dataPointsList3",canvasjsDataList3);
			mav.addObject("dataPointsList4",canvasjsDataList4);
			mav.addObject("mutualList",wrapperList);
			SmartSender obj = SmartSender.getInstance();
			obj.setSmartInstanse(canvasChartService);
		}
		else
		{
			mav = new ModelAndView("login");
			mav.addObject("message","UserName or Password incorrect !");
			
		}
		return mav;
			
	}
	
}

 
 
