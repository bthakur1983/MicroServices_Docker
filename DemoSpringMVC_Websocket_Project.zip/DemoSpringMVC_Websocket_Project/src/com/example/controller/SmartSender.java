package com.example.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.dao.CanvasChartDao;
import com.example.dao.CanvasChartDaoImpl;
import com.example.model.MutualFunds;
import com.example.model.Product;
 



public class SmartSender 
{
	 
	
	public static SmartSender _instance=null;
	public CanvasChartDao canvasChartService = null;
	Timer timer = null;
	static Shaper shaper = null;
	static Shaper2 shaper2 = null;
	static Shaper3 shaper3 = null;
	static Shaper4 shaper4 = null;
	static Shaper5 shaper5 = null;
	public static SmartSender getInstance()
	{
		if(_instance == null)
		{
			
			return _instance = new SmartSender();
		}
		else
			return _instance;
	}
	
	public void setSmartInstanse(CanvasChartDao canvasChartService)
	{
		this.canvasChartService = canvasChartService;
		if(shaper == null)
		{
			shaper = new Shaper(canvasChartService);
			new Thread(shaper).start();
		}
		if(shaper2 == null)
		{
			shaper2 = new Shaper2(canvasChartService);
			new Thread(shaper2).start();
		}
		if(shaper3 == null)
		{
			shaper3 = new Shaper3(canvasChartService);
			new Thread(shaper3).start();
		}
		if(shaper4 == null)
		{
			shaper4 = new Shaper4(canvasChartService);
			new Thread(shaper4).start();
		}
		if(shaper5 == null)
		{
			shaper5 = new Shaper5(canvasChartService);
			new Thread(shaper5).start();
		}
	}
	

}

class Shaper implements Runnable
{
	public CanvasChartDao canvasChartService = null;
	private List<String>itemList=Arrays.asList("Computer","Printer","Computer","Printer");
	private List<String>RemainingQty=Arrays.asList("7","10","4","9","2","1","6","7","23","33","3","10");
	public Shaper(CanvasChartDao canvasChartService) 
	{
		this.canvasChartService = canvasChartService;
		 
	}
	
	@Override
	public void run() 
	{
		  int i=0;
		 while(true)
		 {
			 
			 		if(i<12)
			 		{
			 			try {
							Thread.sleep(12000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						HashMap<String, String> map =new HashMap<>();
						map.put("Computer", RemainingQty.get(i));
						i=i+1;
						map.put("Printer", RemainingQty.get(i));
						i=i+1;
					
						 try {
							WebSocketController.updateDashBoard(map);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						 
			 		}
			 		else
			 		{
			 			i=0;
			 		}
				  
				 
			 }
		 }
		
	}
	
	
class Shaper2 implements Runnable
{
	public CanvasChartDao canvasChartService = null;
	private List<String>populationList1=Arrays.asList("35000","45000","33000","11000","70000"
													   ,"15000","40000","73000","19000","50000"
													   ,"65000","25000","33000","41000","40000"
													   ,"45000","15000","93000","61000","90000");
	
	public Shaper2(CanvasChartDao canvasChartService) 
	{
		this.canvasChartService = canvasChartService;
		 
	}
	
	@Override
	public void run() 
	{
		  int i=0;
		 while(true)
		 {
			 
			 		if(i<15)
			 		{
			 			try {
							Thread.sleep(10000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						HashMap<String, String> map =new HashMap<>();
						map.put("India", populationList1.get(i));
						i=i+1;
						map.put("China", populationList1.get(i));
						i=i+1;
						map.put("England", populationList1.get(i));
						i=i+1;
						map.put("USA", populationList1.get(i));
						i=i+1;
						map.put("Canada", populationList1.get(i));
						i=i+1;
					
						 try {
							WebSocketController.updateDashBoardForChart2(map);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						 
			 		}
			 		else
			 		{
			 			i=0;
			 		}
				  
				 
			 }
		 }
		
	}

class Shaper3 implements Runnable
{
	public CanvasChartDao canvasChartService = null;
 
	
	public Shaper3(CanvasChartDao canvasChartService) 
	{
		this.canvasChartService = canvasChartService;
		 
	}
	
	@Override
	public void run() 
	{
		  int i=0;
		  List<String>XList1=Arrays.asList("x1","x2","x3","x4","x5","x6","x7","x8","x9","x10");
		  List<String>YList1=Arrays.asList("y1","y2","y3","y4","y5","y6","y7","y8","y9","y10");
		  HashMap<String,String> map  = null;
		  
		  
				  
		 while(true)
		 {
			 		if(map!=null && map.size()>0)
			 			map.clear();
			 		map  = new HashMap<String,String>(); 
			 		if(i<15)
			 		{
			 			try {
							Thread.sleep(7000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						 
						int xVal = 600;
						int yVal = 100;
						Random rand = new Random();
						 
						for(int j = 0; j < 10; j++)
						{
							yVal += rand.nextInt(11) - 5;
							map.put(XList1.get(j), ""+j + 1);
							map.put(YList1.get(j), ""+yVal);
							 
						} 
						
	 					
						 try {
							WebSocketController.updateDashBoardForChart3(map);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						 
			 		}
			 		else
			 		{
			 			i=0;
			 		}
				  
				 
			 }
		 }
		
	}
	
class Shaper4 implements Runnable
{
	public CanvasChartDao canvasChartService = null;
 
	
	public Shaper4(CanvasChartDao canvasChartService) 
	{
		this.canvasChartService = canvasChartService;
		 
	}
	
	@Override
	public void run() 
	{
		  int i=0;
		  List<String>XList1=Arrays.asList("x1","x2","x3","x4","x5","x6","x7","x8","x9","x10");
		  List<String>YList1=Arrays.asList("y1","y2","y3","y4","y5","y6","y7","y8","y9","y10");
		  HashMap<String,String> map  = null;
		
		  
				  
		 while(true)
		 {
			 		if(map!=null && map.size()>0)
			 			map.clear();
			 		map  = new HashMap<String,String>(); 
			 		if(i<15)
			 		{
			 			try {
							Thread.sleep(5000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						 
						int xVal = 50000;
						int yVal = 1000;
						Random rand = new Random();
						 
						for(int j = 0; j < 10; j++)
						{
							yVal += rand.nextInt(11) - 5;
							map.put(XList1.get(j), ""+j + 1);
							map.put(YList1.get(j), ""+yVal);
							 
						} 
						
					
						 try {
							WebSocketController.updateDashBoardForChart4(map);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						 
			 		}
			 		else
			 		{
			 			i=0;
			 		}
				  
				 
			 }
		 }
		
	}

class Shaper5 implements Runnable
{
	public CanvasChartDao canvasChartService = null;
 
	
	public Shaper5(CanvasChartDao canvasChartService) 
	{
		this.canvasChartService = canvasChartService;
		 
	}
	
	@Override
	public void run() 
	{
		 int i=0;
		 List<String>mutualItem=Arrays.asList("hdfc","icici","sbi","lic");
		 
		 while(true)
		 {
			 	HashMap<String, Double> map =new HashMap<>();
			 	Random r = new Random();
				MutualFunds mObj = new MutualFunds();
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				for(int j = 0; j < 4; j++)
				{
					 double displayVal = r.nextInt((int)((555.22-100.23)*10+1))+1.23*10 / 10.0;
					switch(j)
					{
					case 0:
						map.put("hdfcfund", displayVal);
						 
						break;
					case 1:
						map.put("sbifund", displayVal);
						break;
					case 2:
						map.put("icicifund", displayVal);
						break;
					case 3:
						map.put("licfund", displayVal);
						break;
					}					 
					 
				}
				
				 try {
						WebSocketController.updateDashBoardForMutualTable(map);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					 
		 }
	}
}