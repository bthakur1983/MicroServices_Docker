package com.example.dao;

import java.util.List;
import java.util.Map;

import com.example.model.Population;
import com.example.model.Product;
 



public interface CanvasChartDao
{
	List<List<Map<Object, Object>>> getCanvasjsChartData(List<Product>totalProdList);
	List<List<Map<Object, Object>>> getCanvasjsDataPopulatonList(List<Population>totalPopList);
	List<List<Map<Object, Object>>> getCanvasjsDataNumberingList();
	List<List<Map<Object, Object>>> getCanvasjsDataNumberingList2();
}
