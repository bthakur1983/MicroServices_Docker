package com.example.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.model.Population;
import com.example.model.Product;
import com.example.utill.CanvasChart;

 
 
@Repository
@Service
public class CanvasChartDaoImpl implements CanvasChartDao {

	@Override
	public List<List<Map<Object, Object>>> getCanvasjsChartData( List<Product>totalProdList) {
		// TODO Auto-generated method stub
		return CanvasChart.getCanvasjsDataList(totalProdList);
	}

	@Override
	public List<List<Map<Object, Object>>> getCanvasjsDataPopulatonList(List<Population> totalPopList) {
		// TODO Auto-generated method stub
		return CanvasChart.getCanvasjsDataPopulatonList(totalPopList);
	}

	@Override
	public List<List<Map<Object, Object>>> getCanvasjsDataNumberingList() {
		// TODO Auto-generated method stub
		return CanvasChart.getCanvasjsDataNumberingList();
		 
	}

	@Override
	public List<List<Map<Object, Object>>> getCanvasjsDataNumberingList2() {
		// TODO Auto-generated method stub
		return CanvasChart.getCanvasjsDataNumberingList2();
	}

}
