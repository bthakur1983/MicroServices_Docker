package com.example.model;

public class MutualFunds 
{
	private double hdfcfund;
	private double icicifund;
	private double sbifund;
	private double licfund;
	public double getHdfcfund() {
		return hdfcfund;
	}
	public void setHdfcfund(double hdfcfund) {
		this.hdfcfund = hdfcfund;
	}
	public double getIcicifund() {
		return icicifund;
	}
	public void setIcicifund(double icicifund) {
		this.icicifund = icicifund;
	}
	public double getSbifund() {
		return sbifund;
	}
	public void setSbifund(double sbifund) {
		this.sbifund = sbifund;
	}
	public double getLicfund() {
		return licfund;
	}
	public void setLicfund(double licfund) {
		this.licfund = licfund;
	}
	
	
	 
	
	

}
