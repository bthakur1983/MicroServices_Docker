package com.example.model;

import java.util.List;

public class WrapperList 
{
	public List<MutualFunds> list ;

	public List<MutualFunds> getList() {
		return list;
	}

	public void setList(List<MutualFunds> list) {
		this.list = list;
	}
	
	

}
