//package com.example.test;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.stereotype.Component;
//
//@Component
//public class Car
//{
// 	@Autowired
//	@Qualifier("vechical2")
//	Vechical vechical;
//	
// 	public Vechical getVechical() {
//		return vechical;
//	}
// 	public void setVechical(Vechical vechical) {
//		this.vechical = vechical;
//	}
// 	
// 	public void displayInformation()
//	{
// 		vechical.setColor("Red");
//		System.out.println("Car Color is : "+vechical.getColor());
//	}
//
//}
