//package com.example.test;
//
//import org.springframework.context.annotation.AnnotationConfigApplicationContext;
//
//public class Main 
//{
//	public static void main(String ar[])
//	{
////		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
////		ctx.register(MyConfiguration.class);
////		ctx.refresh();
////		Car car = ctx.getBean(Car.class);
////		Truck truck = ctx.getBean(Truck.class);
////		car.displayInformation();	
////		truck.displayInformation();
////		ctx.close();
//	}
//}
