//package com.example.test;
//
//import org.springframework.context.annotation.Scope;
//
//
//public class MyBean
//{
//	public MyBean()
//	{
//		System.out.println("instance myBean() created...");
//	}
//
//}
