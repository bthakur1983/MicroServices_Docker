//package com.example.test;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Lazy;
//import org.springframework.context.annotation.Scope;
//
//@Configuration
//public class MyConfiguration
//{
//	 	
//	@Bean
//	//@Lazy
//	public Car getCarColor()
//	{
//		return new Car();
//	}
//	
//	@Bean
//	//@Lazy
//	public Truck getTruckColor()
//	{
//		return new Truck();
//	}
//	
//	@Bean
//	public VechicalImpl getVechical1()
//	{
//		return new VechicalImpl();
//	}
//	
////	@Bean(name="vechical2")
//	@Bean
//	public VechicalImpl getVechical2()
//	{
//		return new VechicalImpl();
//	}
//	
//	 
//}
