//package com.example.test;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.stereotype.Component;
//
//@Component
//public class Truck {
//
//	
//	@Autowired
//	//@Qualifier("vechical1")
//	Vechical vechical;
//	
//	public Truck() {
//		System.out.println("Truck Constructor......");
//	}
//	
// 	public Vechical getVechical() {
//		return vechical;
//	}
// 	public void setVechical(Vechical vechical) {
//		this.vechical = vechical;
//	}
// 	
// 	public void displayInformation()
//	{
// 		vechical.setColor("Black");
//		System.out.println("Truch Color is : "+vechical.getColor());
//	}
//
//}
