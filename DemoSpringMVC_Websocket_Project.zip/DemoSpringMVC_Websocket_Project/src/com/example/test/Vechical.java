//package com.example.test;
//
//public interface Vechical 
//{
//	 
//	public void setColor(String color);
//	public String getColor();
//
//}
