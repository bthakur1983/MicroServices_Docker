//package com.example.test;
//
//public class VechicalImpl implements Vechical 
//{
//	private String color;
//
//	@Override
//	public void setColor(String color) {
//		this.color = color;
//		
//	}
//
//	@Override
//	public String getColor() {
//		// TODO Auto-generated method stub
//		return color;
//	}
//
//}
