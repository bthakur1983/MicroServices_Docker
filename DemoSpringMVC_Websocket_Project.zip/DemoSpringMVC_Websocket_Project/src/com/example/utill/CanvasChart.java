package com.example.utill;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.example.model.Population;
import com.example.model.Product;

 

public class CanvasChart 
{
	
	static Map<Object,Object> map = null;
	static List<List<Map<Object,Object>>> list = new ArrayList<>();
	static List<Map<Object,Object>> dataPoints1 = new ArrayList<Map<Object,Object>>();
	
	static Map<Object,Object> map2 = null;
	static List<List<Map<Object,Object>>> list2 = new ArrayList<>();
	static List<Map<Object,Object>> dataPoints2 = new ArrayList<Map<Object,Object>>();
	
	static Map<Object,Object> map3 = null;
	static List<List<Map<Object,Object>>> list3 = new ArrayList<>();
	static List<Map<Object,Object>> dataPoints3 = new ArrayList<Map<Object,Object>>();
	
	static Map<Object,Object> map4 = null;
	static List<List<Map<Object,Object>>> list4 = new ArrayList<>();
	static List<Map<Object,Object>> dataPoints4 = new ArrayList<Map<Object,Object>>();
	
	 
	  
	 public static void clearList()
	 {
		 if(list.size()>0)
			  list.clear();
		  if(dataPoints1.size()>0)
			  dataPoints1.clear();
		 
	 }
	 public static void clearList2()
	 {
		 
		  if(list2.size()>0)
			  list2.clear();
		  if(dataPoints2.size()>0)
			  dataPoints2.clear();
	 }
	public static List<List<Map<Object, Object>>> getCanvasjsDataList(List<Product>totalProdList)
	{
		clearList();
		for(int i=0;i<totalProdList.size();i++)
		{
		map = new HashMap<Object,Object>();
		map.put("label", totalProdList.get(i).getProd_Name());
		map.put("y",  totalProdList.get(i).getRemaning_Quantity());
		dataPoints1.add(map);
		
		}
		list.add(dataPoints1);
		return list;
	}
	
	public static List<List<Map<Object, Object>>> getCanvasjsDataPopulatonList(List<Population>totalPopList)
	{
		
		clearList2();
		for(int i=0;i<totalPopList.size();i++)
		{
		map = new HashMap<Object,Object>();
		map.put("label", totalPopList.get(i).getCountry());
		map.put("y",  totalPopList.get(i).getPopulation());
		dataPoints2.add(map);
		
		}
		list2.add(dataPoints2);
		return list2;
	}
	
	public static List<List<Map<Object, Object>>> getCanvasjsDataNumberingList()
	{
		
		
		int yVal = 100;
		Random rand = new Random();
		 
		for(int i = 0; i < 10; i++){
			yVal += rand.nextInt(11) - 5;
			map = new HashMap<Object,Object>(); 
			map.put("x", i + 1);
			map.put("y", yVal);
			dataPoints3.add(map);
		}
		
		list3.add(dataPoints3);
		return list3;
	}
	public static List<List<Map<Object, Object>>> getCanvasjsDataNumberingList2()
	{
		
		
		int limit = 50000;
		int yVal = 1000;
		Random rand = new Random();
		 
		for(int i = 0; i < 10; i++){
			yVal += rand.nextInt(11) - 5;
			map = new HashMap<Object,Object>(); 
			map.put("x", i);
			map.put("y", yVal);
			dataPoints4.add(map);
		}
		
		list4.add(dataPoints4);
		return list4;
	}
	
	 
	
	
	
 

}
