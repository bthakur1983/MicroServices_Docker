package com.example.moviecatalogsservice.resources;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


import com.example.moviecatalogsservice.model.Movies;
import com.example.moviecatalogsservice.model.Rating;
import com.example.moviecatalogsservice.model.UserRating;
import com.example.moviecatalogsservice.model.catalogItem;
 

@RestController
@RequestMapping("/catalog")
public class MovieCatalogRecource
{

	@Autowired
	private RestTemplate restTemplate; // this is the threadsafe
	
 
	
	@RequestMapping("/{userId}")
	public List<catalogItem> getCatalogList(@PathVariable("userId")String userId)
	{
		UserRating userRating = restTemplate.getForObject("http://RatingService:8083/ratingdata/users/"+userId, UserRating.class);
		 
		 return userRating.getUserRating().stream().map(rating-> {
				Movies movie = restTemplate.getForObject("http://InfoService:8082/movies/"+rating.getMovieId(), Movies.class);		 
				return new catalogItem(movie.getMovieName(), "hindi movie",rating.getMovieRating());
				}).collect(Collectors.toList());
		 

		
		/*List<Rating>ratingList = Arrays.asList( new Rating("M1001", 1),
				new Rating("M1002", 4),
				new Rating("M1003", 2));

		return ratingList.stream().map(rating-> {
		Movies movie = restTemplate.getForObject("http://InfoService:8082/movies/"+rating.getMovieId(), Movies.class);		 
		return new catalogItem(movie.getMovieName(), "hindi movie",rating.getMovieRating());
		}).collect(Collectors.toList());
				
		*/
	 
	}

}
