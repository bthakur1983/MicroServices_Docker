package com.example.movieratingsservice.resources;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.movieratingsservice.model.Rating;
import com.example.movieratingsservice.model.UserRating;





@RestController
@RequestMapping("/ratingdata")
public class RatingDataResource
{
	public RatingDataResource() {
	System.out.println("RatingDataResource called.........");
	}
	@RequestMapping("/{movieId}")
	public Rating getRating(@PathVariable("movieId")String movieId)
	{
		 
		return new Rating(movieId,4);
	}
	
	@RequestMapping("users/{userId}")
	public UserRating getUserRating(@PathVariable("userId")String userId)
	{
		System.out.println("userRating called............");
		List<Rating>ratingList = Arrays.asList( new Rating("M1001", 1),
				new Rating("M1002", 4),
				new Rating("M1003", 2));
		  UserRating userRating = new UserRating();
		  userRating.setUserRating(ratingList);
		  return userRating;
		 
	}

}
