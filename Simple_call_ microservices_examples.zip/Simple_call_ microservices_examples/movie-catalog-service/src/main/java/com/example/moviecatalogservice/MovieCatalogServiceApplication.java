package com.example.moviecatalogservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

@SpringBootApplication
public class MovieCatalogServiceApplication 
{
	// here we make this method as @Bean because Bean is singoltone in spring so anybody can access this method and get single instance of RestTemplate
	@Bean
	public RestTemplate getInstanseRestTemplate()
	{
		return new RestTemplate();
	}
	
	@Bean
	public WebClient.Builder getWebClientBuilder()
	{
		return WebClient.builder();
	}

	public static void main(String[] args) 
	{
		System.out.println("main called..............");
		SpringApplication.run(MovieCatalogServiceApplication.class, args);
	}

}
