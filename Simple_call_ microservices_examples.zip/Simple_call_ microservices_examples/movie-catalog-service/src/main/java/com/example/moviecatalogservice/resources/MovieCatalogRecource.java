package com.example.moviecatalogservice.resources;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.moviecatalogservice.model.Movies;
import com.example.moviecatalogservice.model.Rating;
import com.example.moviecatalogservice.model.UserRating;
import com.example.moviecatalogservice.model.catalogItem;

@RestController
@RequestMapping("/catalog")
public class MovieCatalogRecource
{

	@Autowired
	private RestTemplate restTemplate; // this is the threadsafe
	
	@Autowired
	private WebClient.Builder webclientBuilder;
	
	@RequestMapping("/{userId}")
	public List<catalogItem> getCatalogList(@PathVariable("userId")String userId)
	{
		
		
		
		
		//1. 1st way
		// 1. *********** RestTemplate used to call other microservices but this is the hard binding in spring no need to create object manually for that we use @Autowired. 
		
		/*List<Rating>ratingList = Arrays.asList( new Rating("M1001", 1),
				new Rating("M1002", 4),
				new Rating("M1003", 2));

		return ratingList.stream().map(rating-> {
		Movies movie = restTemplate.getForObject("http://localhost:8082/movies/"+rating.getMovieId(), Movies.class);		 
		return new catalogItem(movie.getMovieName(), "hindi movie",rating.getMovieRating());
		}).collect(Collectors.toList());
		*/
				
		
		
		
		// 2. *************************** WebClient is the second way to call microservices.	
		
		/*List<Rating>ratingList = Arrays.asList( new Rating("M1001", 1),
												new Rating("M1002", 4),
												new Rating("M1003", 2));
		
		return ratingList.stream().map(rating-> {
			Movies movie = webclientBuilder.build()
					.get()
					.uri("http://localhost:8082/movies/"+rating.getMovieId())
					.retrieve()
					.bodyToMono(Movies.class) // if i dont want data back instently , means for asynchronous
					.block(); // block this till then sombody not fill data
			return new catalogItem(movie.getMovieName(), "hindi movie",rating.getMovieRating());
		}).collect(Collectors.toList());
		
		*/
		
		
		// 3. get rating list by other service
		
		UserRating userRating = restTemplate.getForObject("http://localhost:8083/ratingdata/users/"+userId, UserRating.class);
		
		 
		 return userRating.getUserRating().stream().map(rating-> {
				Movies movie = restTemplate.getForObject("http://localhost:8082/movies/"+rating.getMovieId(), Movies.class);		 
				return new catalogItem(movie.getMovieName(), "hindi movie",rating.getMovieRating());
				}).collect(Collectors.toList());
				 
 
		
		//return Collections.singletonList(new catalogItem("Transformer", "english movie",3));
		
	}

}
